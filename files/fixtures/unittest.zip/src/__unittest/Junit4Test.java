package __unittest;

import static org.junit.Assert.*;

import java.lang.reflect.Modifier;

import org.junit.Test;
import __unittest.Helper;

public class Junit4Test {

	@Test
	public void FibonacciValueTest(){
		// 0,1,1,2,3,5,8,13,21,34,55,89,144
		Helper.InstanceWrapper clazz = (new Helper.ClassWrapper("main.Fibonacci")).create();
		assertEquals("iterFibonacci(0)", 0, (int) clazz.execute("iterFibonacci",0));
		assertEquals("iterFibonacci(1)", 1, (int) clazz.execute("iterFibonacci",1));
		assertEquals("iterFibonacci(2)", 1, (int) clazz.execute("iterFibonacci",2));
		assertEquals("iterFibonacci(3)", 2, (int) clazz.execute("iterFibonacci",3));
		assertEquals("iterFibonacci(4)", 3, (int) clazz.execute("iterFibonacci",4));

		assertEquals("recFibonacci(0)", 0, (int) clazz.execute("recFibonacci",0));
		assertEquals("recFibonacci(1)", 1, (int) clazz.execute("recFibonacci",1));
		assertEquals("recFibonacci(2)", 1, (int) clazz.execute("recFibonacci",2));
		assertEquals("recFibonacci(3)", 2, (int) clazz.execute("recFibonacci",3));
		assertEquals("recFibonacci(4)", 3, (int) clazz.execute("recFibonacci",4));

		assertEquals("exFibonacci(0)", 0, (int) clazz.execute("exFibonacci",0));
		assertEquals("exFibonacci(1)", 1, (int) clazz.execute("exFibonacci",1));
		assertEquals("exFibonacci(2)", 1, (int) clazz.execute("exFibonacci",2));
		assertEquals("exFibonacci(3)", 2, (int) clazz.execute("exFibonacci",3));
		assertEquals("exFibonacci(4)", 3, (int) clazz.execute("exFibonacci",4));
	}
	
	@Test 
	public void FibonacciClassStructureTest(){
		Helper.ClassWrapper clazz  = new Helper.ClassWrapper("main.Fibonacci");
		clazz.hasMethod("iterFibonacci", Modifier.PUBLIC|Modifier.STATIC, int.class, int.class);
		clazz.hasMethod("recFibonacci", Modifier.PUBLIC|Modifier.STATIC, int.class, int.class);
	}

}
