package __unittest;

import static org.junit.Assert.*;

import java.lang.reflect.Modifier;

import org.junit.Test;
import __unittest.Helper;

public class PrintBinaryTest {

	@Test
	public void BinaryToStringValueTest() {
		Helper.InstanceWrapper clazz = new Helper.ClassWrapper("main.PrintInBinary").create();
		assertEquals("intToBinaryString(0)", "0", (String) clazz.execute("intToBinaryString", 0));
		assertEquals("intToBinaryString(1)", "1", (String) clazz.execute("intToBinaryString", 1));
		assertEquals("intToBinaryString(2)", "10", (String) clazz.execute("intToBinaryString", 2));
		assertEquals("intToBinaryString(3)", "11", (String) clazz.execute("intToBinaryString", 3));
	}
	
	@Test
	public void BinaryToStringClassStructureTest() {
		Helper.ClassWrapper clazz = new Helper.ClassWrapper("main.PrintInBinary");
		clazz.hasMethod("intToBinaryString", Modifier.PUBLIC|Modifier.STATIC, String.class, int.class);
	}

}
