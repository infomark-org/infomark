package __unittest;

import static org.junit.Assert.*;

import java.lang.reflect.Modifier;

import org.junit.Test;
import __unittest.Helper;

public class AckermannTest {

	@Test
	public void AckermannValueTest() {
		Helper.InstanceWrapper clazz = (new Helper.ClassWrapper("main.Ackermann")).create();
		assertEquals("ackermann(2, 2)", 7, (int) clazz.execute("ackermann",2,3)); // TODO 3 must be 2
		assertEquals("ackermann(1, 0)", 2, (int) clazz.execute("ackermann",1,0 ));
	}
	
	@Test 
	public void AckermanClassStructureTest(){
		Helper.ClassWrapper clazz  = new Helper.ClassWrapper("main.Ackermann");
		clazz.hasMethod("ackermann", Modifier.PUBLIC|Modifier.STATIC, int.class, int.class, int.class);
	}

}
