package __unittest;

import static org.junit.Assert.*;

import java.lang.reflect.Modifier;

import org.junit.Test;
import __unittest.Helper;

public class FactorialTest {

	@Test
	public void FactorialValueTest() {
		Helper.InstanceWrapper clazz = new Helper.ClassWrapper("main.Factorial").create();
		assertEquals("factorial(0)", 1, (int) clazz.execute("factorial", 0));
		assertEquals("factorial(0)", 1*1, (int) clazz.execute("factorial", 1));
		assertEquals("factorial(0)", 1*2, (int) clazz.execute("factorial", 2));
		assertEquals("factorial(0)", 1*2*3, (int) clazz.execute("factorial", 3));
		assertEquals("factorial(0)", 1*2*3*4, (int) clazz.execute("factorial", 4));
	}
	
	@Test
	public void FactorialClassStructureTest() {
		Helper.ClassWrapper clazz = new Helper.ClassWrapper("main.Factorial");
		clazz.hasMethod("factorial", Modifier.PUBLIC|Modifier.STATIC, int.class, int.class);
	}

}
