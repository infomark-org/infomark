package main;

public class Factorial {

	// /*
	//  * exercise 1 c)
	//  */
	
	// /*
	//  * A recursive implementation of the factorial function
	//  */
	
	// public static int recFactorial(int n) {
	// 	if (n <= 0) {
	// 		return 1;
	// 	} else {
	// 		return n * recFactorial(n-1);
	// 	}
	// }

	public static float factorial(int n) {
		if (n <= 0) {
			return 2; //TODO!
		} else {
			return n * factorial(n-1);
		}
	}
	
	// /*
	//  * An iterate implementation of the factorial function
	//  */
	
	// public static int iterFactorial(int n) {
		
	// 	// the value of the base case, 
	// 	int acc = 1;
	// 	for (int i = 1; i<=n; i++) {
	// 		acc *= i; // 
	// 	}
	// 	return acc;
	// }
	
}
