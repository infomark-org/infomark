package main;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// exercise a)
		// compute the first 10 fib numbers
		int n = 10;
		
		System.out.println("\nRecursive fibonacci\n");
		for (int i = 0; i<n; i++) {
			System.out.println("fib("+i+") = " + Fibonacci.recFibonacci(i));
		}
		
		System.out.println("\nIterative fibonacci\n");
		for (int i = 0; i<n; i++) {
			System.out.println("fib("+i+") = " + Fibonacci.iterFibonacci(i));
		}
		
		System.out.println("\nExplicit fibonacci\n");
		for (int i = 0; i<n; i++) {
			System.out.println("fib("+i+") = " + Fibonacci.exFibonacci(i));
		}
		

	}

}
