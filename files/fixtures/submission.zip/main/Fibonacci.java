package main;

public class Fibonacci {
	
	/*
	 * exercise 1 a)
	 */
	
	/*
	 * A recursive implementation of fibonacci
	 */
	
	public static int recFibonacci(int n) {
		if (n <= 0) {
			return 0;
		} else if (n == 1) {
			return 1;
		} else {
			return recFibonacci(n-1) + recFibonacci(n-2);
		}
	}
	
	/*
	 * An iterative implementation of fibonacci
	 */
	
	public static int iterFibonacci(int n) {


		int x = 0, y = 1, z = 1;
    for (int i = 0; i < n; i++) {
        x = y;
        y = z;
        z = x + y;
    }
    return x;


		
	}
	
	/*
	 * An explicit implementation of fibonacci
	 */
	
	public static double phi = (1 + Math.sqrt(5)) / 2; 
	public static int exFibonacci(int n) {
		return (int) Math.floor(0.5 + ((Math.pow(phi, n)) / Math.sqrt(5)));
	}
	

}
