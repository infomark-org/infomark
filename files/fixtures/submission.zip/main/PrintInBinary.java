package main;

public class PrintInBinary {

	/*
	 * exercise 1 d)
	 */
	
	/*
	 * A recursive function which prints an integer in its binary representation.
	 */
	
	public static void printInBinary(int n) {
		
		// is the integer zero, so just print it
		if (n == 0) {
			System.out.print(0);
			return;
		}
		
		// print the bits before the last bit, n/2 == n >> 1
		printInBinary(n/2);
		
		// is the last bit set
		if (n % 2 == 1) {
			System.out.print(1);
		} else {
			System.out.print(0);
		}
		
	}
	
	
	
	public static String intToBinaryString(int n) {
		// base case: n <= 1
		if (n == 0 || n == 1) {
			return n + ""; // Integer.toString(n)
		} else {
			return intToBinaryString(n>>1) 
					+ (n % 2 == 1 ? "1" : "0");
		}				 		
	}
	
	public static void main(String[] args) {
		int n = 10;
		for (int i = 0; i < n; i++) {
			printInBinary(i);
			System.out.println();
			System.out.println(intToBinaryString(i));
		}
	}
	
}
